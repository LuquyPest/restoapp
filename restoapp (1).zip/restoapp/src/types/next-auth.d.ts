import "next-auth"
import "next-auth/jwt"

declare module "next-auth" {
  interface Session {
    user: {
      id: string
      email: string
      name?: string | null
      role: string
      restaurantId: string
    }
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role?: string
    restaurantId?: string
  }
}
